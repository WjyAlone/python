#!/bin/sh

PYTHONPATH= python `dirname $0`/liblink "$@"
