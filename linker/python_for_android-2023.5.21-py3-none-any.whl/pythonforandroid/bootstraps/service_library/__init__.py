from pythonforandroid.bootstraps.service_only import ServiceOnlyBootstrap


class ServiceLibraryBootstrap(ServiceOnlyBootstrap):

    name = 'service_library'


bootstrap = ServiceLibraryBootstrap()
